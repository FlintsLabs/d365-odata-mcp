//! Config module

pub mod config;

pub use config::{Config, EntityConfig, ProductType, RuntimeConfig};
